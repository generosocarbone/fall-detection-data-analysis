import serial
import time
from serial import rs485
import struct
from paho.mqtt.client import Client
import asyncio
import json

async def read_sensor_data():
	global client
	while True:

		if not ser.is_open:
			ser.open()

		try:
			x = ser.write(bytearray(b'\x55\x03\x01\x01\x00\x00\x00\x00\x8A\x19'))
		except Error:
			print("Some error occurred!")

		# print("write: {}".format(x))
		answer = ser.read(10)
		ser.close()
		unpacked = struct.unpack('<f', bytearray([answer[5], answer[4], answer[7], answer[6]]))[0]
		print(json.dumps({"typology":"GasSensor","zone":1,"sector":1,"value":unpacked}))
		try:
			client.publish("sensor", json.dumps({"typology":"GasSensor","zone":1,"sector":1,"value":unpacked}), qos=2)
		except Error:
			print("Some error occurred!")
		time.sleep(5)


def on_connect(client, userdata, flags, rc):
	print("Connesso con successo")
	asyncio.run(read_sensor_data())


def on_message(client, userdata, message):
	print("on message")
	#print( message.payload.decode() )


def on_subscribe(client, userdata, mid, granted_qos):
	print("Subscribed")


def on_publish(client, userdata, mid):
	print("on publish")

def on_log(mosq, obj, level, string):
    print(string)

baudrate = 2400
port = "/dev/FTDI102"

ser = serial.Serial(port=port, baudrate = baudrate, bytesize = serial.EIGHTBITS, stopbits = serial.STOPBITS_ONE, timeout = 2, write_timeout=2)
print("Port: {}\nBaudrate: {}\nserial: {}".format(port, baudrate, ser))

client = Client(client_id = "clientId-lqdvClrAag", clean_session=False, transport="tcp")
# client = Client(client_id = "client_1", clean_session=False, transport="websockets")
client.on_connect = on_connect
client.on_publish = on_publish
client.on_subscribe = on_subscribe
client.on_message = on_message
print("client creato")

client.username_pw_set("sensortest", "sensortest")
# client.connect("stream.lifesensor.cloud", 9001)
client.connect("192.168.2.38", 8000 )
client.subscribe("sensor", qos=2)
print("client connesso")
client.loop_forever()
