import pandas
import matplotlib.pyplot as plt

print(pandas.__version__)

G = 9.81
MAX_A = 2 * G

def analyze_dataframe(df, title):
    print('\n__dataframe: {}__'.format(title))
    print('var   \t{}'.format(df['a'].var()))
    print('med   \t{}'.format(df['a'].median()))
    print(df['a'].describe())
    spike = df[df['a'] > MAX_A]['a']
    print(spike)
    print(spike.size)
    df.plot.line()


csv_name='fall_1615570226899.csv'
riposo = pandas.read_csv(csv_name, sep=';')
analyze_dataframe(riposo, csv_name)

plt.show()
